package bank.domains;

public enum OperationType {
    INCOME,
    EXPENSE
}